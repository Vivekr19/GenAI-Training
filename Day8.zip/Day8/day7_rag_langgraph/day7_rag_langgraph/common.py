"""
Shared building blocks — every example imports from here so we don't repeat
ourselves and so the "same model both sides" rule from Slide 8 is impossible
to break.

What lives here:
    QDRANT_URL, COLLECTION       — names & endpoints
    DENSE_MODEL_NAME             — pinned embedding model (Slide 27)
    embed_texts(), embed_query() — the one-way door — call THESE, never the model directly
    sparse_embed_*()             — BM25-style sparse vectors for hybrid search
    get_qdrant()                 — singleton QdrantClient
    get_llm()                    — Gemini if GEMINI_API_KEY set, else a deterministic fake
"""
from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

# Load .env from project root regardless of which sub-folder we're running from.
load_dotenv(Path(__file__).parent / ".env")


# --------------------------------------------------------------------
# Constants — Slide 8 says: pin these once and never change them
# --------------------------------------------------------------------
QDRANT_URL: str = os.getenv("QDRANT_URL", "http://localhost:6333")
COLLECTION: str = "kb"

# fastembed model names. We default to small, fast, CPU-friendly models so
# students can run the entire deck on a laptop with no API keys.
DENSE_MODEL_NAME: str = "BAAI/bge-small-en-v1.5"   # 384 dims, ~130MB
SPARSE_MODEL_NAME: str = "Qdrant/bm25"             # classic lexical, no training
DENSE_DIM: int = 384                                # locked at collection creation


# --------------------------------------------------------------------
# Embedders — Slide 8: same model both sides
# --------------------------------------------------------------------
@lru_cache(maxsize=1)
def _dense_model():
    # Imported lazily — fastembed pulls a model on first use (~one-time download).
    from fastembed import TextEmbedding
    return TextEmbedding(model_name=DENSE_MODEL_NAME)


@lru_cache(maxsize=1)
def _sparse_model():
    from fastembed import SparseTextEmbedding
    return SparseTextEmbedding(model_name=SPARSE_MODEL_NAME)


def embed_texts(texts: list[str]) -> list[list[float]]:
    """Batched dense embeddings — use this for ingestion (Slide 14)."""
    return [list(v) for v in _dense_model().embed(texts)]


def embed_query(text: str) -> list[float]:
    """Single dense embedding — use this at query time."""
    return list(next(_dense_model().query_embed(text)))


def sparse_embed_documents(texts: list[str]):
    """Returns fastembed SparseEmbedding objects (indices + values)."""
    return list(_sparse_model().embed(texts))


def sparse_embed_query(text: str):
    return next(_sparse_model().query_embed(text))


# --------------------------------------------------------------------
# Qdrant client — one per process
# --------------------------------------------------------------------
@lru_cache(maxsize=1)
def get_qdrant():
    from qdrant_client import QdrantClient
    return QdrantClient(url=QDRANT_URL)


# --------------------------------------------------------------------
# LLM — real Gemini if a key is set, else a fake so demos still run
# --------------------------------------------------------------------
def get_llm():
    """Returns a langchain-compatible chat model (.invoke takes messages)."""
    api_key = os.getenv("GEMINI_API_KEY")
    print(f"[DEBUG] GEMINI_API_KEY loaded: {'set' if api_key else 'NOT SET'}")
    if api_key:
        from langchain_google_genai import ChatGoogleGenerativeAI
        print(f"[DEBUG] Using Gemini model: {os.getenv('GEMINI_MODEL', 'gemini-2.5-flash')}")
        return ChatGoogleGenerativeAI(
            model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
            temperature=0,
        )
    # Fallback: predictable fake so students without API keys can still run
    # the LangGraph chapters end-to-end.
    return _FakeLLM()


class _FakeLLM:
    """Pretends to be a chat model. Returns a citation-shaped answer built
    deterministically from whatever context was stitched into the prompt."""

    def invoke(self, messages):
        from langchain_core.messages import AIMessage
        # Find the human message (last)
        human_text = ""
        for m in messages:
            if m.__class__.__name__ == "HumanMessage":
                human_text = m.content
        # Naive: echo first chunk text + a fake citation if we can find one
        import re
        citations = re.findall(r"\[([a-zA-Z0-9_\-]+__chunk-\d+)\]", human_text)
        cite = citations[0] if citations else "no-citation"
        return AIMessage(
            content=f"[fake-llm] Based on the retrieved context, here is an "
                    f"answer for your question. See [{cite}] for the source. "
                    f"(Set GEMINI_API_KEY in .env for real model output.)"
        )

    # For tasks that ask the model to grade / rewrite — return a fixed string.
    def grade(self) -> str:
        return "good"
