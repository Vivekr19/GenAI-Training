"""
Capstone HTTP — FastAPI endpoint that streams the chat reply.

Slide 23: 'langchain-google-genai streams Gemini tokens — pipe through
FastAPI to the client.' This file shows both shapes:
    POST /chat        non-streaming JSON     (easy to curl)
    POST /chat/stream Server-Sent Events     (live tokens to a browser / EventSource)

Run (from project root):
    cd 06_capstone
    uv run uvicorn app:app --reload --port 8000

Quick test in another terminal:
    curl.exe -X POST http://localhost:8000/chat ^
         -H "Content-Type: application/json" ^
         -d "{\"question\": \"How do I cancel my subscription?\", \"tenant_id\": \"acme-corp\"}"

(PowerShell users: the ^ is a line continuation; or paste it on one line.
 SSE stream: hit /chat/stream — easiest from a browser EventSource.)
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import json
from typing import Optional

from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from graph import chat_graph

app = FastAPI(title="Day 7 capstone — RAG chat")


class ChatRequest(BaseModel):
    question:  str
    tenant_id: str = "acme-corp"


class ChatResponse(BaseModel):
    answer:    str
    documents: list[dict]
    attempts:  int


def _seed_state(req: ChatRequest) -> dict:
    return {
        "tenant_id": req.tenant_id,
        "question":  req.question,
        "rewritten": "",
        "documents": [],
        "grade":     "",
        "attempts":  0,
        "messages":  [],
        "answer":    "",
    }


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    """Non-streaming: run the whole graph, return the final state."""
    result = chat_graph.invoke(_seed_state(req))
    return ChatResponse(
        answer=result["answer"],
        documents=[
            {"id": d["id"], "source": d.get("source"), "score": d["score"]}
            for d in result["documents"]
        ],
        attempts=result["attempts"],
    )


@app.post("/chat/stream")
def chat_stream(req: ChatRequest):
    """Server-Sent Events: stream graph events as they happen.

    LangGraph's .stream() yields one update per node firing. The browser /
    client gets retrieval progress THEN the final answer — visible latency
    feels much shorter than a single blocking call."""

    def event_iter():
        for update in chat_graph.stream(_seed_state(req)):
            # update is a dict like {"retrieve": {"documents": [...]}}
            for node_name, patch in update.items():
                # Strip Message objects to keep the SSE payload JSON-clean
                clean = {k: v for k, v in patch.items() if k != "messages"}
                yield f"event: {node_name}\ndata: {json.dumps(clean, default=str)}\n\n"
        yield "event: done\ndata: {}\n\n"

    return StreamingResponse(event_iter(), media_type="text/event-stream")
