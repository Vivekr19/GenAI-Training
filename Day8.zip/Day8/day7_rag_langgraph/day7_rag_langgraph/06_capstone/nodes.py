"""
Slides 20–23 — The four nodes of the chat graph.

Each is a plain function:  state in → dict patch out.
No node imports LangGraph; the graph builder in graph.py wires them together.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from typing import Annotated, TypedDict

from langchain_core.messages import (
    BaseMessage, HumanMessage, SystemMessage, AIMessage,
)
from langgraph.graph.message import add_messages
from qdrant_client import models

from common import (
    get_qdrant, embed_query, sparse_embed_query, get_llm, COLLECTION,
)


# --------------------- shared state (Slide 21) ----------------------
class ChatState(TypedDict):
    tenant_id: str
    question: str                        # raw user turn (this turn)
    rewritten: str                       # standalone form for retrieval
    documents: list[dict]                # Qdrant hits
    grade: str                           # 'good' | 'weak'
    attempts: int                        # loop cap
    messages: Annotated[list[BaseMessage], add_messages]
    answer: str


# ====================== retrieval helper ============================
def hybrid_search(query: str, tenant_id: str, k: int = 6):
    """Slide 17 hybrid search — tenant filter is mandatory."""
    if not tenant_id:
        # Slide 27: 'Wrap retrieval so it cannot be called without a tenant_id.'
        raise ValueError("tenant_id is required — refusing cross-tenant search")

    qdrant = get_qdrant()
    dense_vec = embed_query(query)
    sparse = sparse_embed_query(query)

    return qdrant.query_points(
        collection_name=COLLECTION,
        prefetch=[
            models.Prefetch(query=dense_vec, using="dense", limit=30),
            models.Prefetch(
                query=models.SparseVector(
                    indices=sparse.indices.tolist(),
                    values=sparse.values.tolist(),
                ),
                using="sparse",
                limit=30,
            ),
        ],
        query=models.FusionQuery(fusion=models.Fusion.RRF),
        query_filter=models.Filter(must=[
            models.FieldCondition(
                key="tenant_id",
                match=models.MatchValue(value=tenant_id),
            )
        ]),
        limit=k,
        with_payload=True,
    ).points


# ====================== nodes (Slides 22–23) ========================
def rewrite(state: ChatState) -> dict:
    """Slide 20 — turn a follow-up into a standalone question.

    If there's no prior history, the question IS standalone — passthrough.
    Otherwise we ask the LLM to rewrite given the chat history."""
    if not state.get("messages"):
        return {"rewritten": state["question"]}
    print("inside rewrite node, history is:", state["messages"])
    llm = get_llm()
    print("llm is:", llm)
    sys_prompt = SystemMessage(content=(
        "Given the chat history and the user's latest question, "
        "rewrite the latest question as a STANDALONE question. "
        "Reply with the rewritten question only, no preamble."
    ))
    history_text = "\n".join(
        f"{type(m).__name__}: {m.content}" for m in state["messages"][-6:]
    )
    user = HumanMessage(content=f"History:\n{history_text}\n\nLatest: {state['question']}")

    try:
        reply = llm.invoke([sys_prompt, user])
        rewritten = reply.content.strip() or state["question"]
    except Exception:
        # Fall back to the raw question if the LLM call fails
        rewritten = state["question"]

    return {"rewritten": rewritten}


def retrieve(state: ChatState) -> dict:
    """Slide 22 — pure function, returns a patch."""
    hits = hybrid_search(
        query=state["rewritten"],
        tenant_id=state["tenant_id"],
        k=6,
    )
    docs = [
        {
            "id":     h.id,
            "text":   h.payload["text"],
            "source": h.payload.get("source_url"),
            "score":  h.score,
        }
        for h in hits
    ]
    return {"documents": docs}


def grade(state: ChatState) -> dict:
    """Slide 20 — let the LLM decide whether the chunks cover the question.

    For the offline / no-key fallback path the fake LLM always returns 'good',
    which means the loop exits on the first pass — predictable for demos."""
    if not state["documents"]:
        return {"grade": "weak"}

    llm = get_llm()
    if hasattr(llm, "grade"):                # the _FakeLLM shortcut
        return {"grade": llm.grade()}

    context = "\n\n".join(f"- {d['text'][:300]}" for d in state["documents"][:6])
    prompt = [
        SystemMessage(content=(
            "Decide whether the provided context can answer the question. "
            "Reply with exactly one word: 'good' or 'weak'."
        )),
        HumanMessage(content=f"Question: {state['rewritten']}\n\nContext:\n{context}"),
    ]
    try:
        reply = llm.invoke(prompt).content.strip().lower()
        return {"grade": "good" if reply.startswith("good") else "weak"}
    except Exception:
        return {"grade": "good"}             # don't get stuck on LLM errors


SYSTEM_PROMPT = (
    "Answer using ONLY the context. Cite each fact as [doc-id]. "
    "If the context is insufficient, say so plainly — do not guess."
)


def generate(state: ChatState) -> dict:
    """Slide 23 — grounded, cited."""
    llm = get_llm()
    context = "\n\n".join(
        f"[{d['id']}] {d['text']}" for d in state["documents"]
    )
    msgs = [
        SystemMessage(content=SYSTEM_PROMPT),
        *state.get("messages", []),
        HumanMessage(content=f"Question: {state['rewritten']}\n\nContext:\n{context}"),
    ]
    reply = llm.invoke(msgs)
    return {
        "messages": [HumanMessage(content=state["question"]), AIMessage(content=reply.content)],
        "answer":   reply.content,
    }
