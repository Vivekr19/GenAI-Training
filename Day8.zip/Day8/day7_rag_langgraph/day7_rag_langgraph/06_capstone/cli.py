"""
Capstone CLI — chat with the graph in your terminal.

Multi-turn: the messages channel accumulates, so 'and what about Q4?'
gets rewritten into a standalone question using the prior turns.

Prereq: 03_ingestion/02_pipeline.py has been run so 'kb' has data.

Run:
    uv run python 06_capstone/cli.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))   # let imports find nodes / graph

from rich import print
from rich.prompt import Prompt
from rich.rule import Rule

from graph import chat_graph

TENANT = "acme-corp"


def main() -> None:
    print(Rule("[bold]Day 7 capstone — RAG + LangGraph chat[/bold]"))
    print(f"Tenant: [cyan]{TENANT}[/cyan]   "
          "Type 'quit' to exit.  Try a follow-up like 'and what about Pro?'")
    print()

    # The state lives in this dict across turns. messages accumulates;
    # everything else is per-turn and overwritten.
    history: list = []

    while True:
        try:
            q = Prompt.ask("[bold green]you[/bold green]")
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if q.strip().lower() in {"quit", "exit", "q"}:
            break
        if not q.strip():
            continue

        result = chat_graph.invoke({
            "tenant_id": TENANT,
            "question":  q,
            "rewritten": "",
            "documents": [],
            "grade":     "",
            "attempts":  0,
            "messages":  history,
            "answer":    "",
        })

        # Persist the new turn's messages for the next iteration
        history = result["messages"]

        print(f"[bold blue]assistant[/bold blue]: {result['answer']}\n")

        # Show what was retrieved — that's the 'citations come free' part
        if result["documents"]:
            print("[dim]sources used:[/dim]")
            for d in result["documents"][:3]:
                print(f"  [dim]- [{d['id']}]  score={d['score']:+.4f}[/dim]")
        print()


if __name__ == "__main__":
    main()
