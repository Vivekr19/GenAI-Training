"""
Slide 24 — Compile the chat graph once, invoke per request.
"""
from langgraph.graph import StateGraph, START, END

from nodes import (
    ChatState, rewrite, retrieve, grade, generate,
)


def _route_after_grade(state: ChatState) -> str:
    """Slide 24 router — verbatim from the deck.

    Loop back to refine if the chunks were weak, but cap retries so we
    always answer something within a bounded number of attempts.
    """
    if state["grade"] == "good" or state["attempts"] >= 2:
        return "generate"
    return "rewrite_again"


def _bump_attempts(state: ChatState) -> dict:
    """Tiny helper node — increments the attempts counter before looping back.
    Lets the router see that we've tried, and stop after 2 tries."""
    return {"attempts": state.get("attempts", 0) + 1}


def build_graph():
    g = StateGraph(ChatState)
    g.add_node("rewrite",        rewrite)
    g.add_node("retrieve",       retrieve)
    g.add_node("grade",          grade)
    g.add_node("generate",       generate)
    g.add_node("rewrite_again",  _bump_attempts)  # bump counter, then go to rewrite

    g.add_edge(START,            "rewrite")
    g.add_edge("rewrite",        "retrieve")
    g.add_edge("retrieve",       "grade")
    g.add_conditional_edges("grade", _route_after_grade, {
        "generate":       "generate",
        "rewrite_again":  "rewrite_again",
    })
    g.add_edge("rewrite_again", "rewrite")
    g.add_edge("generate",       END)

    return g.compile()


# Compile once at import time (Slide 24 — 'reuse across requests')
chat_graph = build_graph()
