"""
Slides 16–17 — Hybrid search (dense + sparse + RRF)
====================================================
ONE round trip to Qdrant:
    * dense prefetch (top 30 by meaning)
    * sparse prefetch (top 30 by lexical)
    * Reciprocal Rank Fusion (RRF) merges into a single ranked list

Run:
    uv run python 04_search/03_hybrid_search.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich import print
from qdrant_client import models
from common import (
    get_qdrant, embed_query, sparse_embed_query, COLLECTION,
)

qdrant = get_qdrant()


def hybrid_search(query: str, k: int = 5):
    """The Slide-17 function — adapted to our named-vector setup."""
    dense_vec = embed_query(query)
    sparse = sparse_embed_query(query)

    return qdrant.query_points(
        collection_name=COLLECTION,
        prefetch=[
            models.Prefetch(query=dense_vec, using="dense", limit=30),
            models.Prefetch(
                query=models.SparseVector(
                    indices=sparse.indices.tolist(),
                    values=sparse.values.tolist(),
                ),
                using="sparse",
                limit=30,
            ),
        ],
        query=models.FusionQuery(fusion=models.Fusion.RRF),   # the fusion step
        limit=k,
        with_payload=True,
    ).points


# Same two queries — now both should work
for q in [
    "How do I end my plan?",
    "CVE-2024-3094 mitigation steps",
    "What's the rate limit on the API?",
]:
    print(f"\n[bold]Query:[/bold] {q!r}")
    for r in hybrid_search(q, k=3):
        text = r.payload["text"].replace("\n", " ")
        print(f"  [RRF score={r.score:+.4f}]  {r.payload['document_id']:20}  {text[:90]}...")

print("""
[dim]Takeaway (Slide 16):[/dim]
'Pick hybrid. Meaning catches paraphrase. Keywords catch rare tokens.
RRF needs no tuning.'
""")
