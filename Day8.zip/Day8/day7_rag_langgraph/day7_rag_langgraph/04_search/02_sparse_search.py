"""
Slide 15 — Sparse search alone (BM25)
======================================
Lexical match. The rare exact string ('HTTP 429', error codes, SKUs,
proper nouns) scores very high. The paraphrase ('quit the service' vs
'cancel subscription') loses.

Run AFTER 03_ingestion/02_pipeline.py:
    uv run python 04_search/02_sparse_search.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich import print
from qdrant_client import models
from common import get_qdrant, sparse_embed_query, COLLECTION

qdrant = get_qdrant()

queries = [
    "I want to quit the service",      # paraphrase — sparse will struggle
    "HTTP 429",                        # exact token — sparse will dominate
]

for q in queries:
    print(f"\n[bold]Query:[/bold] {q!r}")
    sv = sparse_embed_query(q)
    results = qdrant.query_points(
        collection_name=COLLECTION,
        query=models.SparseVector(
            indices=sv.indices.tolist(),
            values=sv.values.tolist(),
        ),
        using="sparse",
        limit=3,
        with_payload=True,
    ).points
    if not results:
        print("  [yellow]no hits[/yellow]")
        continue
    for r in results:
        text = r.payload["text"].replace("\n", " ")
        print(f"  [{r.score:+.3f}]  {r.payload['document_id']:20}  {text[:90]}...")

print("""
[dim]Watch:[/dim] The 'HTTP 429' query nails the right doc with a clear gap.
'I want to quit the service' may return the wrong doc — none of the docs
literally say those words. That's why sparse alone isn't enough either.
""")
