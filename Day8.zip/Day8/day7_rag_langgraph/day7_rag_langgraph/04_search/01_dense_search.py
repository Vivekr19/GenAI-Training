"""
Slide 15 — Dense search alone
==============================
Embedding similarity catches MEANING (paraphrase, synonym, intent) but
can miss rare exact tokens.

Run AFTER 03_ingestion/02_pipeline.py:
    uv run python 04_search/01_dense_search.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich import print
from common import get_qdrant, embed_query, COLLECTION

qdrant = get_qdrant()

# Two queries — one paraphrase-y (dense wins), one with a rare exact token
# (dense will struggle).
queries = [
    "I want to quit the service",             # paraphrase of 'cancel subscription'
    "HTTP 429",                               # exact-string query
]

for q in queries:
    print(f"\n[bold]Query:[/bold] {q!r}")
    results = qdrant.query_points(
        collection_name=COLLECTION,
        query=embed_query(q),
        using="dense",                        # name from named-vectors config
        limit=3,
        with_payload=True,
    ).points
    for r in results:
        text = r.payload["text"].replace("\n", " ")
        print(f"  [{r.score:+.3f}]  {r.payload['document_id']:20}  {text[:90]}...")

print("""
[dim]Watch:[/dim] the paraphrase query ('quit the service') finds the billing doc.
The exact-string 'HTTP 429' query will likely fail to put the API doc first
because '429' isn't semantically rich enough for the dense model.
""")
