"""
Slide 17 — Filter + hybrid search (the production default)
===========================================================
Composing a payload Filter with any retrieval mode is the safety net for
multi-tenant systems: 'narrow first, then rank' (Slide 15).

We:
    1. Temporarily insert a fake 'globex-ltd' chunk into the SAME collection
    2. Show that a query WITHOUT a tenant filter pulls cross-tenant junk
    3. Show that adding tenant_id='acme-corp' keeps results clean
    4. Clean up the fake point

Run AFTER 03_ingestion/02_pipeline.py:
    uv run python 04_search/04_filtered_search.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from uuid import uuid4
from rich import print
from qdrant_client import models
from common import (
    get_qdrant, embed_query, sparse_embed_query, embed_texts,
    sparse_embed_documents, COLLECTION,
)

qdrant = get_qdrant()


# ---- 1) Spike the collection with a different-tenant point -----------
spike_text = "Globex confidential: rate limit raised to 5000 rps for partner accounts."
dvec = embed_texts([spike_text])[0]
svec = sparse_embed_documents([spike_text])[0]
SPIKE_ID = str(uuid4())

qdrant.upsert(
    collection_name=COLLECTION,
    points=[models.PointStruct(
        id=SPIKE_ID,
        vector={
            "dense":  dvec,
            "sparse": models.SparseVector(
                indices=svec.indices.tolist(),
                values=svec.values.tolist(),
            ),
        },
        payload={
            "document_id": "globex-secret",
            "tenant_id":   "globex-ltd",            # different tenant!
            "source_url":  "internal://globex/secret.md",
            "text":        spike_text,
        },
    )],
    wait=True,
)


def hybrid_search(query: str, tenant: str | None, k: int = 4):
    dense_vec = embed_query(query)
    sparse = sparse_embed_query(query)

    query_filter = None
    if tenant:
        query_filter = models.Filter(must=[
            models.FieldCondition(
                key="tenant_id",
                match=models.MatchValue(value=tenant),
            )
        ])

    return qdrant.query_points(
        collection_name=COLLECTION,
        prefetch=[
            models.Prefetch(query=dense_vec, using="dense", limit=30),
            models.Prefetch(
                query=models.SparseVector(
                    indices=sparse.indices.tolist(),
                    values=sparse.values.tolist(),
                ),
                using="sparse",
                limit=30,
            ),
        ],
        query=models.FusionQuery(fusion=models.Fusion.RRF),
        query_filter=query_filter,
        limit=k,
        with_payload=True,
    ).points


q = "What is the API rate limit?"
print(f"[bold]Query:[/bold] {q!r}\n")

print("[bold red]UNFILTERED (leaks Globex's secret):[/bold red]")
for r in hybrid_search(q, tenant=None):
    text = r.payload["text"].replace("\n", " ")
    print(f"  [{r.payload['tenant_id']:11}]  [{r.score:+.4f}]  {text[:80]}...")

print("\n[bold green]FILTERED tenant_id='acme-corp' (safe):[/bold green]")
for r in hybrid_search(q, tenant="acme-corp"):
    text = r.payload["text"].replace("\n", " ")
    print(f"  [{r.payload['tenant_id']:11}]  [{r.score:+.4f}]  {text[:80]}...")

print("""
[dim]Takeaway (Slide 27):[/dim] wrap your retrieval function so it CAN'T be
called without a tenant_id. That's exactly what hybrid_search does in
06_capstone/nodes.py.
""")

# ---- Tidy: remove the spike so other examples aren't polluted --------
qdrant.delete(
    collection_name=COLLECTION,
    points_selector=models.PointIdsList(points=[SPIKE_ID]),
    wait=True,
)
print(f"\n[dim]Removed spike point {SPIKE_ID}.[/dim]")
