# Setup — Windows + WSL (Qdrant in Docker)

This project runs **Python on Windows** and **Qdrant on WSL in Docker**. WSL 2 auto-forwards container ports to Windows `localhost`, so the Python code just hits `http://localhost:6333`.

~10 minutes if you have WSL and Docker already; ~25 minutes from scratch.

---

## 1. Prerequisites — checked in 30 seconds

Open **PowerShell** on Windows and run each:

```powershell
wsl --status
docker --version
python --version          # 3.10 or higher
```

If any of these fails, install in this order:

| Missing | How to install |
|---|---|
| WSL | `wsl --install -d Ubuntu` (admin PowerShell), then reboot |
| Docker | [Docker Desktop](https://www.docker.com/products/docker-desktop/) — during install tick *"Use WSL 2 based engine"* |
| Python 3.10+ | [python.org](https://www.python.org/downloads/) installer — tick *"Add python.exe to PATH"* |

> Docker Desktop on Windows runs the engine **inside** WSL automatically. You do **not** need to install Docker manually inside Ubuntu.

---

## 2. Start Qdrant inside WSL

Open **Ubuntu** (Windows Terminal → `wsl` or the Start-menu Ubuntu shortcut), then:

```bash
# Confirm Docker is reachable from inside WSL
docker ps

# Pull and run Qdrant — single command, mounts a volume so data survives restarts
docker run -d \
  --name qdrant \
  -p 6333:6333 \
  -p 6334:6334 \
  -v qdrant_storage:/qdrant/storage \
  qdrant/qdrant
```

- `6333` is the REST/HTTP port (what our Python client uses).
- `6334` is the gRPC port (faster; you can opt into it later).

### Verify

From either Windows PowerShell or WSL — both work because of port forwarding:

```bash
curl http://localhost:6333/healthz
# Expected: "healthz check passed"
```

Open the **Qdrant dashboard** in your Windows browser: <http://localhost:6333/dashboard> — you should see an empty collections list.

### Useful Qdrant commands

```bash
docker ps                          # is it running?
docker stop qdrant                 # stop
docker start qdrant                # start again (data preserved)
docker rm -f qdrant                # destroy container (data preserved in the volume)
docker volume rm qdrant_storage    # wipe ALL stored vectors (dev only)
docker logs -f qdrant              # tail logs
```

---

## 3. Install `uv` on Windows

`uv` is a fast Python package + project manager. We use it to install dependencies once for the entire repo.

In **PowerShell**:

```powershell
# Official installer
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"

# Reopen PowerShell, then:
uv --version
```

---

## 4. Install project dependencies

```powershell
cd path\to\day7_rag_langgraph
uv sync
```

That single command:
1. Reads `pyproject.toml`
2. Creates a `.venv\` in the project folder
3. Installs every dependency

To use the venv interactively (you usually don't need to — `uv run` handles it):

```powershell
.\.venv\Scripts\activate
```

---

## 5. (Optional) Configure API keys

The project runs **without any API keys** by default — embeddings use the local `fastembed` model, and the LangGraph capstone uses a deterministic fake LLM that produces sensible-looking output.

To use real models (Gemini), copy `.env.example` to `.env` and fill in:

```powershell
copy .env.example .env
notepad .env
```

```ini
GEMINI_API_KEY=AIza...your-key...
```

The code auto-detects the key and switches over.

---

## 6. Run your first example

```powershell
uv run python 01_embeddings\01_what_is_embedding.py
```

The first run downloads the `BAAI/bge-small-en-v1.5` model (~130 MB, one time). Subsequent runs are instant.

---

## Common gotchas

| Symptom | Fix |
|---|---|
| `curl: command not found` in PowerShell | Use `curl.exe http://localhost:6333/healthz` — PowerShell aliases `curl` to a different cmdlet |
| `Connection refused` on `:6333` | Qdrant not running — `docker start qdrant` (or `docker ps` to check) |
| Qdrant port not reachable from Windows | WSL 2 normally forwards `localhost` automatically. If not, restart Docker Desktop; failing that, `wsl --shutdown` and reopen |
| `uv: command not found` after install | Reopen PowerShell — the installer modifies PATH only for new shells |
| Fastembed model download fails | First run needs the internet. After that everything is local (cached under `%USERPROFILE%\.cache\fastembed`) |
| Want to wipe and restart Qdrant from scratch | `docker rm -f qdrant && docker volume rm qdrant_storage`, then re-run the `docker run` from step 2 |

---

## You're ready

Open `README.md` for the section-by-section walkthrough, or jump to `01_embeddings\01_what_is_embedding.py`.
