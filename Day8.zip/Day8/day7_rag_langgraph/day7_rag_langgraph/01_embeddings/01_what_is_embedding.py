"""
Slide 7 — Vector embeddings: meaning as coordinates
====================================================
A piece of text becomes a list of floats. Texts with similar meaning land
near each other in vector space. We can measure 'near' with cosine similarity.

Run:
    uv run python 01_embeddings/01_what_is_embedding.py
"""
import sys
from pathlib import Path

# Make `common` importable from any sub-folder without an installed package
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import math
from rich import print
from common import embed_query, DENSE_MODEL_NAME, DENSE_DIM


def cosine(a: list[float], b: list[float]) -> float:
    """Cosine similarity = dot(a, b) / (|a| · |b|). Bounded [-1, 1]."""
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    return dot / (norm_a * norm_b)


# Three texts from the deck. First two say the same thing two ways.
# The third is unrelated.
texts = [
    "Cancel my subscription",
    "How do I unsubscribe?",
    "Why is the sky blue?",
]

print(f"[bold]Embedding model:[/bold] {DENSE_MODEL_NAME}  ({DENSE_DIM} dimensions)\n")

vectors = [embed_query(t) for t in texts]

print(f"Each text became a list of {len(vectors[0])} floats. First 5 of each:")
for t, v in zip(texts, vectors):
   
    print(f"  {t!r:32}  →  {[float(x) for x in v[:10]]}  ...")
print()

# Now compute pairwise similarity. Expect 0/1 to be high; 0/2 and 1/2 low.
print("[bold]Pairwise cosine similarity:[/bold]")
for i in range(len(texts)):
    for j in range(i + 1, len(texts)):
        sim = cosine(vectors[i], vectors[j])
        verdict = "[green]similar[/green]" if sim > 0.7 else "[red]different[/red]"
        print(f"  {texts[i]!r:32}  vs  {texts[j]!r:32}  →  {sim:+.3f}  {verdict}")

print("""
[dim]Takeaway:[/dim] semantic search = nearest-neighbour lookup in this space.
That's the whole idea behind dense retrieval.
""")
