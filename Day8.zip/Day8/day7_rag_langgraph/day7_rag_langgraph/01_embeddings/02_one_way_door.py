"""
Slide 8 — The embedding model is a one-way door
================================================
Whatever model embedded your documents MUST also embed your queries. Different
models = different vector spaces = nonsense similarities.

This script demonstrates the failure:
    * Embed the same text with two different models
    * Try to compare the vectors
    * Watch the similarity collapse to noise

Run:
    uv run python 01_embeddings/02_one_way_door.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import math
from rich import print
from fastembed import TextEmbedding


def cosine(a, b):
    """Truncate to common length first — needed because the two models have
    different dimensions (384 vs 512). Even after truncation the result is
    nonsense; that's the whole point."""
    n = min(len(a), len(b))
    a, b = a[:n], b[:n]
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


# Pick two genuinely different embedding models.
MODEL_A = "BAAI/bge-small-en-v1.5"      # 384 dims
MODEL_B = "sentence-transformers/all-MiniLM-L6-v2"  # 384 dims, different training

text_pairs = [
    ("Cancel my subscription", "How do I unsubscribe?"),
    ("How do I deploy my app?", "Steps to ship to production"),
]

print("[bold]Loading two embedding models...[/bold] (first run downloads them)\n")
model_a = TextEmbedding(model_name=MODEL_A)
model_b = TextEmbedding(model_name=MODEL_B)


def embed(model, text):
    return list(next(model.query_embed(text)))


print("[bold yellow]Case 1 — Same model both sides (correct usage):[/bold yellow]")
for q1, q2 in text_pairs:
    v1 = embed(model_a, q1)
    v2 = embed(model_a, q2)
    print(f"  {q1!r:38} vs {q2!r:38}  →  sim={cosine(v1, v2):+.3f}  [green](meaningful)[/green]")

print("\n[bold red]Case 2 — Different models (the bug):[/bold red]")
for q1, q2 in text_pairs:
    v1 = embed(model_a, q1)   # ingested with A
    v2 = embed(model_b, q2)   # queried with B
    print(f"  {q1!r:38} vs {q2!r:38}  →  sim={cosine(v1, v2):+.3f}  [red](noise — different spaces)[/red]")

print("""
[dim]Takeaway:[/dim] pin the embedding model in config at ingest time and never
let queries use a different one. In this project that's enforced in common.py
— every example imports [bold]embed_query()[/bold] / [bold]embed_texts()[/bold]
from the same module, so they cannot drift.
""")
