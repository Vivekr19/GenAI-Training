"""
Slide 13 — Payload: metadata is what makes search useful
=========================================================
The point's payload determines what you can:
    * filter on at query time (tenant_id, timestamp, doc_type, language)
    * cite back to the user (source_url, section_title)
    * de-dupe and upsert cleanly (document_id + chunk_index → stable ID)

This script:
    1. Creates a small collection
    2. Inserts the EXACT payload shape from Slide 13 — multi-tenant
    3. Demonstrates filtered search (tenant-scoped)

Run:
    uv run python 02_qdrant/02_payload_shape.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from uuid import uuid4
from rich import print
from rich.json import JSON
from qdrant_client import models
from common import get_qdrant, embed_query, DENSE_DIM

DEMO_COLLECTION = "demo_payload"

qdrant = get_qdrant()
if qdrant.collection_exists(DEMO_COLLECTION):
    qdrant.delete_collection(DEMO_COLLECTION)
qdrant.create_collection(
    collection_name=DEMO_COLLECTION,
    vectors_config=models.VectorParams(size=DENSE_DIM, distance=models.Distance.COSINE),
)

# Two tenants, similar questions in each — filter must keep them apart.
records = [
    # ACME
    ("acme-corp", "doc-4f2a", 0, "Q3 Revenue Breakdown",
     "Acme Q3 revenue grew 14% YoY, driven by enterprise expansion."),
    ("acme-corp", "doc-4f2a", 1, "Q3 Revenue Breakdown",
     "Acme cost of goods sold rose 9%, leaving gross margin at 71%."),
    # GLOBEX (totally different numbers — must not leak into ACME results)
    ("globex-ltd", "doc-9c33", 0, "Q3 Revenue Breakdown",
     "Globex Q3 revenue fell 2% YoY due to FX headwinds."),
    ("globex-ltd", "doc-9c33", 1, "Q3 Revenue Breakdown",
     "Globex restructured its EMEA sales org during Q3."),
]


def to_point(tenant, doc_id, chunk_idx, section, text):
    return models.PointStruct(
        id=uuid4(),      # stable ID — Slide 14
        vector=embed_query(text),
        payload={                                    # exact shape from Slide 13
            "document_id":   doc_id,
            "chunk_index":   chunk_idx,
            "tenant_id":     tenant,
            "source_url":    f"https://kb.{tenant}/{doc_id}.pdf",
            "timestamp":     "2025-10-14T09:31:00Z",
            "section_title": section,
            "language":      "en",
            "text":          text,
        },
    )


points = [to_point(*r) for r in records]
qdrant.upsert(collection_name=DEMO_COLLECTION, points=points, wait=True)
print(f"[bold]Inserted[/bold] {len(points)} points across 2 tenants.\n")

# Show one full payload — this is exactly the shape Slide 13 displays
print("[bold]One point as Qdrant sees it:[/bold]")
sample = qdrant.retrieve(
    collection_name=DEMO_COLLECTION,
    ids=[points[0].id],
    with_payload=True, with_vectors=False,
)[0]
print(JSON.from_data({"id": sample.id, "payload": sample.payload}))
print()


# ---- Show why the filter matters --------------------------------------
query = "How was Q3 revenue?"
qvec = embed_query(query)


def search(tenant: str | None):
    """tenant=None → no filter (the bug). tenant='x' → safe."""
    flt = None
    if tenant:
        flt = models.Filter(must=[
            models.FieldCondition(
                key="tenant_id",
                match=models.MatchValue(value=tenant),
            )
        ])
    return qdrant.query_points(
        collection_name=DEMO_COLLECTION,
        query=qvec,
        query_filter=flt,
        limit=4,
        with_payload=True,
    ).points


print(f"[bold]Query:[/bold] {query!r}\n")
print("[bold red]Without tenant filter (LEAK):[/bold red]")
for r in search(None):
    print(f"  [{r.payload['tenant_id']:11}]  {r.payload['text']}")

print("\n[bold green]With tenant_id='acme-corp' filter (safe):[/bold green]")
for r in search("acme-corp"):
    print(f"  [{r.payload['tenant_id']:11}]  {r.payload['text']}")

print("""
[dim]Takeaway:[/dim] put tenant_id (and any other scoping key) in payload
[bold]before[/bold] you ingest. Every retrieval call must filter on it.
Slide 27: 'Tenant filter, always.'
""")

qdrant.delete_collection(DEMO_COLLECTION)
