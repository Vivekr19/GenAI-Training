"""
Slide 9 — Qdrant in three concepts: collection, point, payload
===============================================================
    Collection — a namespace with a FIXED vector config (dim + distance metric)
    Point      — one record: id + vector + payload
    Payload    — JSON metadata you can filter on

We:
    1. Create a tiny demo collection
    2. Upsert two points
    3. Query and inspect them
    4. Clean up

Run:
    uv run python 02_qdrant/01_collection_basics.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich import print
from qdrant_client import models
from common import get_qdrant, embed_query, DENSE_DIM

DEMO_COLLECTION = "demo_basics"

qdrant = get_qdrant()

# ---- 1) Create collection ----------------------------------------------
# Slide 9: "Set once. Cannot change without re-ingesting."
print(f"[bold]Creating collection[/bold] {DEMO_COLLECTION!r} "
      f"(dim={DENSE_DIM}, distance=COSINE)")

# Delete-if-exists, then create — repeatable demos
if qdrant.collection_exists(DEMO_COLLECTION):
    qdrant.delete_collection(DEMO_COLLECTION)
qdrant.create_collection(
    collection_name=DEMO_COLLECTION,
    vectors_config=models.VectorParams(
        size=DENSE_DIM,
        distance=models.Distance.COSINE,   # cosine for normalised text vectors
    ),
)

# ---- 2) Upsert two points ---------------------------------------------
texts = [
    "Cancel my subscription",
    "Why is the sky blue?",
]

points = [
    models.PointStruct(
        id=i,
        vector=embed_query(t),
        payload={"text": t, "source": "demo", "lang": "en"},   # arbitrary JSON
    )
    for i, t in enumerate(texts)
]

print(f"[bold]Upserting[/bold] {len(points)} points...")
qdrant.upsert(collection_name=DEMO_COLLECTION, points=points, wait=True)

# ---- 3) Search ---------------------------------------------------------
query = "How do I unsubscribe?"
print(f"\n[bold]Query:[/bold] {query!r}")

results = qdrant.query_points(
    collection_name=DEMO_COLLECTION,
    query=embed_query(query),
    limit=2,
    with_payload=True,   # ask Qdrant to send the payload back inline
).points

for r in results:
    print(f"  score={r.score:+.3f}  id={r.id}  payload={r.payload}")

print("""
[dim]Takeaway:[/dim] one collection, many points; each point's payload is the
metadata you'll filter on at query time. The text itself lives in the
payload — Qdrant returns it inline, so you don't need a separate document store.
""")

# ---- 4) Tidy up --------------------------------------------------------
# qdrant.delete_collection(DEMO_COLLECTION)
# print(f"[dim]Deleted demo collection {DEMO_COLLECTION!r}.[/dim]")
