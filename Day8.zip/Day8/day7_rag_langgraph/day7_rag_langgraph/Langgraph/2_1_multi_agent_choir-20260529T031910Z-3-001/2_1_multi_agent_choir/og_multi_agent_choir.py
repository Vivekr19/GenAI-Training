from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from datetime import datetime
import time
from langchain_ollama import ChatOllama


def get_llm():
    # Adjust to your environment
    return ChatOllama(
        model="llama3",
        base_url="http://127.0.0.1:11434",
        temperature=0.1,  # keep it steady for extraction/classification
        format="json",
    )


llm = get_llm()


def pause(seconds):
    time.sleep(seconds)


def log(name, event_type):
    timestamp = datetime.now().strftime("%H:%M:%S")
    emoji = "🟢" if event_type == "START" else "✅"
    print(f"[{timestamp}] {emoji} {event_type:<5} {name}")


class ChoirState(TypedDict):
    user_input: str
    funny: str
    formal: str
    poetic: str
    response: str


def funny_agent(state):
    log("funny_agent node", "START")
    pause(2)
    user_input = state["user_input"]

    system_prompt = """
    You are a funny assistant. Reply to the user input with humor.
    Output Format : 
    {
        "message":string
    }
    """

    response = llm.invoke(
        [
            {
                "role": "system",
                "content": system_prompt,
            },
            {
                "role": "user",
                "content": f"{user_input}",
            },
        ]
    )
    log("funny_agent node", "END")
    return {"funny": response.content}


def formal_agent(state):
    log("formal_agent node", "START")
    pause(2)
    user_input = state["user_input"]
    system_prompt = """
    You are a formal assistant. Reply to the user input with formality.
    Output Format : 
    {
        "message":string
    }
    """

    response = llm.invoke(
        [
            {
                "role": "system",
                "content": system_prompt,
            },
            {
                "role": "user",
                "content": f"{user_input}",
            },
        ]
    )
    log("formal_agent node", "END")
    return {"formal": response.content}


def poetic_agent(state):
    log("poetic_agent node", "START")
    pause(2)
    user_input = state["user_input"]
    system_prompt = """
    You are a poetic assistant. Reply to the user input in a poetic way.
    Output Format : 
    {
        "message":string
    }
    """

    response = llm.invoke(
        [
            {
                "role": "system",
                "content": system_prompt,
            },
            {
                "role": "user",
                "content": f"{user_input}",
            },
        ]
    )
    log("poetic_agent node", "END")
    return {"poetic": response.content}


def conductor(state):
    return {"response": f"{state['funny']}\n{state['formal']}\n{state['poetic']}"}


workflow = StateGraph(ChoirState)

workflow.add_node("funny_agent", funny_agent)
workflow.add_node("formal_agent", formal_agent)
workflow.add_node("poetic_agent", poetic_agent)
workflow.add_node("conductor", conductor)

workflow.add_edge(START, "funny_agent")
workflow.add_edge(START, "formal_agent")
workflow.add_edge(START, "poetic_agent")
workflow.add_edge(["funny_agent", "formal_agent", "poetic_agent"], "conductor")
workflow.add_edge("conductor", END)

app = workflow.compile()


def get_response_from_graph(user_input: str):
    input_data = {"user_input": user_input}
    return app.invoke(input_data)


def generate_answer(user_input):
    print("\n============================================================")
    print("Starting Graph Execution\n")
    value = get_response_from_graph(user_input)

    print("\n============================================================")
    print("Final Output from Graph Execution:\n")

    for key, val in value.items():
        print(f"{key}: {val}\n")

    print("============================================================\n")


generate_answer("Hii!! my name is Ayush.")
