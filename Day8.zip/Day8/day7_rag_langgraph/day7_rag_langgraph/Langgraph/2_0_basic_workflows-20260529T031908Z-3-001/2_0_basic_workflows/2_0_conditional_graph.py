from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from datetime import datetime
import time


def pause(seconds):
    time.sleep(seconds)


def log(name, event_type):
    timestamp = datetime.now().strftime("%H:%M:%S")
    emoji = "🟢" if event_type == "START" else "✅"
    print(f"[{timestamp}] {emoji} {event_type:<5} {name}")


# Define a typed dictionary for tracking the state of the graph
class GraphState(TypedDict):
    first_digit: int
    second_digit: int

    result: int

    response: str


def first_agent(state):
    log("first_agent", "START")

    first_digit = state["first_digit"]
    second_digit = state["second_digit"]

    print("First Agent : Calculating the sum of two digits...")

    result = first_digit + second_digit

    pause(1)

    log("first_agent", "END")
    return {"result": result}


def routing_function(state):
    log("routing_function", "START")

    result = state["result"]

    pause(1)

    print(
        "Routing Function : Determines which agent to call next based on the result..."
    )

    log("routing_function", "END")

    if result % 2 == 0:
        return "call third_agent"
    else:
        return "call fourth_agent"


def third_agent(state):
    log("third_agent", "START")

    first_digit = state["first_digit"]
    second_digit = state["second_digit"]
    result = state["result"]
    pause(1)

    third_agent_response = f"The addition of {first_digit} and {second_digit} is {result}, which is an EVEN number."

    log("third_agent", "END")
    return {"response": third_agent_response}


def fourth_agent(state):
    log("fourth_agent", "START")

    first_digit = state["first_digit"]
    second_digit = state["second_digit"]
    result = state["result"]
    pause(1)

    fourth_agent_response = f"The addition of {first_digit} and {second_digit} is {result}, which is an ODD number."

    log("fourth_agent", "END")
    return {"response": fourth_agent_response}


workflow = StateGraph(GraphState)

workflow.add_node("first_agent", first_agent)
workflow.add_node("third_agent", third_agent)
workflow.add_node("fourth_agent", fourth_agent)

workflow.add_edge(START, "first_agent")

workflow.add_conditional_edges(
    "first_agent",
    routing_function,
    {"call third_agent": "third_agent", "call fourth_agent": "fourth_agent"},
)
workflow.add_edge("third_agent", END)
workflow.add_edge("fourth_agent", END)

app = workflow.compile()


def get_response_from_graph(first_digit: int, second_digit: int):
    input_data = {"first_digit": first_digit, "second_digit": second_digit}
    return app.invoke(input_data)


def generate_answer(first_digit: int, second_digit: int):
    print("\n============================================================")
    print("Starting Graph Execution\n")
    value = get_response_from_graph(first_digit, second_digit)

    print("\n============================================================")
    print("Final Output from Graph Execution:\n")

    for key, val in value.items():
        print(f"{key}: {val}\n")

    print("============================================================\n")


# generate_answer(5, 10)

generate_answer(2, 2)
