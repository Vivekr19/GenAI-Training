from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from datetime import datetime
import time


def pause(seconds):
    time.sleep(seconds)


def log(node_name, event_type):
    timestamp = datetime.now().strftime("%H:%M:%S")
    emoji = "🟢" if event_type == "START" else "✅"
    print(f"[{timestamp}] {emoji} {event_type:<5} {node_name}")


# Define a typed dictionary for tracking the state of the graph
class GraphState(TypedDict):
    user_input: str

    response: str

    first_agent_response: str
    second_agent_response: str
    third_agent_response: str


def first_agent(state):
    log("first_agent", "START")

    user_input = state["user_input"]
    first_agent_response = (
        f'{user_input}\nFirst agent said: "Hi there! How can I assist you today?"'
    )
    pause(5)

    log("first_agent", "END")
    return {"first_agent_response": first_agent_response}


def second_agent(state):
    log("second_agent", "START")

    first_agent_response = state["first_agent_response"]
    pause(3)

    second_agent_response = (
        first_agent_response
        + "\nSecond agent said: I'm here to help! What do you need assistance with?\n"
    )

    log("second_agent", "END")
    return {"second_agent_response": second_agent_response}


def third_agent(state):
    log("third_agent", "START")

    first_agent_response = state["first_agent_response"]
    pause(1)

    third_agent_response = (
        first_agent_response + "\nThird agent said: Feel free to ask me anything!\n"
    )

    log("third_agent", "END")
    return {"third_agent_response": third_agent_response}


def fourth_agent(state):
    log("fourth_agent", "START")

    first_agent_response = state["first_agent_response"]
    second_agent_response = state["second_agent_response"]
    third_agent_response = state["third_agent_response"]

    # Combine responses cleanly
    fourth_agent_response = "\n".join(
        [
            first_agent_response,
            second_agent_response.split("\n", 1)[-1],
            third_agent_response.split("\n", 1)[-1],
            "Fourth agent said: Goodbye!\n",
        ]
    )

    pause(1)
    log("fourth_agent", "END")
    return {"response": fourth_agent_response}


# Workflow definition
workflow = StateGraph(GraphState)
workflow.add_node("first_agent", first_agent)
workflow.add_node("second_agent", second_agent)
workflow.add_node("third_agent", third_agent)
workflow.add_node("fourth_agent", fourth_agent)

workflow.add_edge(START, "first_agent")
workflow.add_edge("first_agent", "second_agent")
workflow.add_edge("first_agent", "third_agent")
workflow.add_edge(["second_agent", "third_agent"], "fourth_agent")
workflow.add_edge("fourth_agent", END)

app = workflow.compile()


def get_response_from_graph(user_input: str):
    input_data = {"user_input": user_input}
    return app.invoke(input_data)


def generate_answer(user_input):
    print("\n============================================================")
    print("Starting Graph Execution\n")
    value = get_response_from_graph(user_input)

    print("\n============================================================")
    print("Final Output from Graph Execution:\n")

    for key, val in value.items():
        print(f"{key}: {val}\n")

    print("============================================================\n")


generate_answer("Hii!! my name is Ayush.")
