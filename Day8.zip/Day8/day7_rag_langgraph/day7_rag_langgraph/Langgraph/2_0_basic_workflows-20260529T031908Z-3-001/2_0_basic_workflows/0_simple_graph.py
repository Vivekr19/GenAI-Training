from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from datetime import datetime
import time


def pause(seconds):
    time.sleep(seconds)


def log(name, event_type):
    timestamp = datetime.now().strftime("%H:%M:%S")
    emoji = "🟢" if event_type == "START" else "✅"
    print(f"[{timestamp}] {emoji} {event_type:<5} {name}")


# Define a typed dictionary for tracking the state of the graph
class GraphState(TypedDict):
    user_input: str

    response: str


def first_agent(state):
    log("first_agent", "START")

    user_input = state["user_input"]
    response = state.get("response", "")

    response += f"{user_input}\nFirst agent said: Hi there! How can I assist you today?"

    pause(5)

    log("first_agent", "END")
    return {"response": response}


def second_agent(state):
    log("second_agent", "START")

    response = state["response"]

    pause(3)

    log("second_agent", "END")
    response += (
        "\nSecond agent said: I'm here to help! What do you need assistance with?\n"
    )

    return {"response": response}


workflow = StateGraph(GraphState)

workflow.add_node("first_agent", first_agent)
workflow.add_node("second_agent", second_agent)

workflow.add_edge(START, "first_agent")
workflow.add_edge("first_agent", "second_agent")
workflow.add_edge("second_agent", END)

app = workflow.compile()


def get_response_from_graph(user_input: str):
    input_data = {"user_input": user_input}
    return app.invoke(input_data)


def generate_answer(user_input):
    print("\n============================================================")
    print("Starting Graph Execution\n")
    value = get_response_from_graph(user_input)

    print("\n============================================================")
    print("Final Output from Graph Execution:\n")

    for key, val in value.items():
        print(f"{key}: {val}\n")

    print("============================================================\n")


generate_answer("Hii!! my name is Ayush.")
