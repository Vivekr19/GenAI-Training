# Security Advisory — CVE-2024-3094 Mitigation Guide

## Summary

On March 29, 2024, a malicious backdoor was discovered in the xz-utils
compression library, tracked as CVE-2024-3094. The compromised versions
are 5.6.0 and 5.6.1, distributed primarily through upstream tarballs
between February and March 2024.

The backdoor targets OpenSSH servers and could allow unauthorized remote
code execution under specific build configurations.

## Affected Systems

Linux distributions that shipped xz-utils 5.6.0 or 5.6.1 in their unstable
or testing branches between February 2024 and March 29, 2024. Stable
production releases of major distributions were generally not affected.

To check whether your system carries an affected version:

    xz --version

If the reported version is 5.6.0 or 5.6.1, proceed with the mitigation
steps below.

## Mitigation Steps

1. Downgrade xz-utils to version 5.4.6 or any prior 5.4.x release.
2. Restart the OpenSSH daemon: `systemctl restart sshd`.
3. Audit `~/.ssh/authorized_keys` for unexpected entries.
4. Rotate SSH host keys if the system was exposed to the public internet
   while running an affected version.

For internet-facing servers, treat any system that ran 5.6.0 or 5.6.1
even briefly as potentially compromised; rebuild from a clean image.

## References

CISA Advisory: https://www.cisa.gov/news-events/alerts/2024/03/29/reported-supply-chain-compromise-affecting-xz-utils
