# Acme Cloud Platform — Product Handbook

## Subscriptions and Billing

Acme Cloud offers three plans: Starter, Pro, and Enterprise. You can change
plans at any time from the billing settings page. Downgrades take effect at
the end of the current billing cycle, while upgrades take effect immediately
and the next invoice is prorated.

To cancel your subscription, navigate to Settings → Billing → Cancel
Subscription. Cancellation takes effect at the end of the current billing
period; you retain full access until that date.

Refunds are issued only for service outages exceeding the SLA defined in
your contract. Contact billing@acme.example for refund inquiries.

## Single Sign-On (SSO)

The Pro and Enterprise plans support SAML 2.0 single sign-on with any
compliant identity provider (Okta, Azure AD, Google Workspace, OneLogin).

To configure SSO, an account administrator must upload the IdP metadata XML
under Settings → Security → SSO. Once enabled, password login is disabled
for all non-admin users in the tenant.

## API Rate Limits

The default rate limit on the Acme Cloud API is 100 requests per second per
API key, with a burst capacity of 200. Enterprise customers can request
higher limits by contacting support.

Exceeded requests return HTTP 429 with a Retry-After header. Clients should
implement exponential backoff on 429 responses.
