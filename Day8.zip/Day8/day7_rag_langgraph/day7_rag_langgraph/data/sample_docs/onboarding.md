# Acme Cloud — New Customer Onboarding

## Day 1 — Account Setup

After you sign up, you will receive a welcome email containing a one-time
activation link. The link expires 24 hours after issuance. Click the link
to verify your email address and set your initial password.

Once activated, your account is provisioned with a 14-day free trial of
the Pro plan. No payment method is required during the trial. You may
downgrade to Starter at any time.

## Day 2 — Inviting Your Team

Navigate to Settings → Team → Invite Members. Enter the email addresses of
the colleagues you want to add, choose their role (Admin, Developer, or
Viewer), and click Send Invitations.

Invited users receive an email with a join link, valid for 7 days. You can
revoke or resend invitations from the same page.

The maximum team size depends on your plan:
- Starter: 5 users
- Pro: 25 users
- Enterprise: unlimited

## Day 3 — First Deployment

Acme Cloud supports deployment via the web console, the CLI (`acme`
command), or the REST API.

The fastest path to a running service is the CLI. After installing the
CLI and running `acme login`, deploying is a single command:

    acme deploy ./my-app

This packages your application, uploads it to the Acme Cloud build
service, and routes traffic to the new revision once the health check
passes.

## Getting Help

Documentation is available at https://docs.acme.example. For account
issues, email support@acme.example. Pro and Enterprise customers may
also open a ticket directly from the web console.
