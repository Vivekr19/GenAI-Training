# Day 7 — RAG + LangGraph (Runnable Examples)

Section-by-section code companion for the Day 7 deck. Every file is small, focused on one slide / one concept, and **runnable on its own** with `uv run python <file>`.

## What's in here

```
day7_rag_langgraph/
├── setup.md                ← Qdrant in WSL Docker + uv on Windows (read first)
├── pyproject.toml          ← ONE uv project; one venv shared by every example
├── .env.example            ← optional API keys (all examples run without)
├── common.py               ← shared clients / embedders / LLM helper
├── data/sample_docs/       ← 3 tiny knowledge-base docs we ingest in part 3
│
├── 01_embeddings/          ← Part 01 of the deck
│   ├── 01_what_is_embedding.py    Slide 7  — meaning becomes coordinates
│   └── 02_one_way_door.py         Slide 8  — same model both sides or junk results
│
├── 02_qdrant/              ← Part 01 (continued)
│   ├── 01_collection_basics.py    Slide 9  — collection / point / payload
│   └── 02_payload_shape.py        Slide 13 — what to put in payload, and why
│
├── 03_ingestion/           ← Part 02 of the deck
│   ├── 01_chunking.py             Slide 12 — size / overlap / boundaries
│   └── 02_pipeline.py             Slide 14 — full ingest of data/sample_docs
│
├── 04_search/              ← Part 02 (continued)
│   ├── 01_dense_search.py         Slide 15 — meaning
│   ├── 02_sparse_search.py        Slide 15 — keywords
│   ├── 03_hybrid_search.py        Slides 16–17 — fused, the production default
│   └── 04_filtered_search.py      Slide 17 — tenant filter, the safety lever
│
├── 05_langgraph/           ← Part 03 of the deck
│   ├── 01_state.py                Slide 21 — typed state with reducers
│   ├── 02_minimal_graph.py        intro    — two nodes, one edge
│   ├── 03_conditional_edge.py     Slide 24 — branching + loop with cap
│   └── 04_visualize.py            Slide 25 — draw the graph as ASCII + PNG
│
└── 06_capstone/            ← Part 03 capstone (Slides 20–26)
    ├── nodes.py                   rewrite · retrieve · grade · generate
    ├── graph.py                   compile the chat graph
    ├── cli.py                     interactive chat in the terminal
    └── app.py                     FastAPI streaming endpoint
```

## How to run

After `setup.md`:

```powershell
# from the project root
uv run python 01_embeddings\01_what_is_embedding.py
uv run python 02_qdrant\01_collection_basics.py
# ...etc
```

Each file prints what it's doing and why. Read the file, run it, look at the output.

## Suggested order

1. **`setup.md`** — get Qdrant + uv working (one-time).
2. **`01_embeddings/`** then **`02_qdrant/`** — the building blocks.
3. **`03_ingestion/02_pipeline.py`** — this writes ~25 chunks into Qdrant. **Run this once before any `04_search/` example** — the search demos read what ingestion wrote.
4. **`04_search/`** — all four search modes, side by side.
5. **`05_langgraph/`** — graph mechanics in isolation, no LLM needed.
6. **`06_capstone/`** — the full chat pipeline. CLI first, then FastAPI streaming.

## Conventions

- **Qdrant at `http://localhost:6333`** — change in `.env` if yours is elsewhere.
- **Collection name: `kb`** — defined once in `common.py`. Every example uses it.
- **No API keys required.** Embeddings = local FastEmbed. LLM = real Gemini if you set `GEMINI_API_KEY`, else a deterministic fake that prints a sensible answer shape.
- **`common.py` is the only shared file.** Each example folder otherwise has only its own files — no cross-folder imports.
