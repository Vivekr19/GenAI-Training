"""
Slide 14 — Ingestion pipeline: chunk → batch-embed → upsert
============================================================
The pipeline from the slide, with one production add-on the deck mentions later:
we also write SPARSE vectors so the hybrid search examples in 04_search/ can
fuse dense + sparse without re-ingesting.

What this does:
    1. Recreates the 'kb' collection with BOTH dense and sparse vector slots
    2. Walks data/sample_docs/, chunks every .md file
    3. Batch-embeds all chunks (one call per model)
    4. Upserts points with stable IDs and the Slide-13 payload shape

Re-runnable: stable IDs mean a second run UPSERTS in place — no duplicates.

Run:
    uv run python 03_ingestion/02_pipeline.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich import print
from rich.progress import track
from qdrant_client import models
from langchain_text_splitters import RecursiveCharacterTextSplitter
from uuid import uuid4

from common import (
    get_qdrant, embed_texts, sparse_embed_documents,
    COLLECTION, DENSE_DIM,
)

DOCS_DIR = Path(__file__).resolve().parent.parent / "data" / "sample_docs"
TENANT_ID = "acme-corp"   # for the demos we ingest everything under one tenant


# ---- 1) Set up the collection -----------------------------------------
qdrant = get_qdrant()

print(f"[bold]Recreating collection[/bold] {COLLECTION!r} "
      f"with named dense + sparse vector slots")

# Named vectors so a single point can carry BOTH dense and sparse — Qdrant
# fuses them in one query (see 04_search/03_hybrid_search.py).
if qdrant.collection_exists(COLLECTION):
    qdrant.delete_collection(COLLECTION)
qdrant.create_collection(
    collection_name=COLLECTION,
    vectors_config={
        "dense": models.VectorParams(size=DENSE_DIM, distance=models.Distance.COSINE),
    },
    sparse_vectors_config={
        "sparse": models.SparseVectorParams(),
    },
)

# ---- 2) Walk docs and chunk -------------------------------------------
splitter = RecursiveCharacterTextSplitter(
    chunk_size=600,
    chunk_overlap=80,
    separators=["\n\n", "\n", ". ", " ", ""],
)

records: list[tuple[str, int, str, str]] = []  # (doc_id, chunk_idx, source, text)
for md in sorted(DOCS_DIR.glob("*.md")):
    doc_id = md.stem
    text = md.read_text(encoding="utf-8")
    for i, ch in enumerate(splitter.split_text(text)):
        records.append((doc_id, i, str(md.name), ch))

print(f"[bold]Chunked[/bold] {len(set(r[0] for r in records))} docs → {len(records)} chunks")

# ---- 3) Batch-embed (Slide 14 — one call per ~100 chunks) -------------
chunk_texts = [r[3] for r in records]

print(f"[bold]Embedding[/bold] dense vectors...")
dense_vecs = embed_texts(chunk_texts)

print(f"[bold]Embedding[/bold] sparse vectors (BM25)...")
sparse_vecs = sparse_embed_documents(chunk_texts)

# ---- 4) Upsert ---------------------------------------------------------
points = []
for (doc_id, idx, source, text), dv, sv in zip(records, dense_vecs, sparse_vecs):
    points.append(models.PointStruct(       # stable → re-runs upsert in place
        id=uuid4(),      # stable ID — Slide 14
        vector={
            "dense":  dv,
            "sparse": models.SparseVector(
                indices=sv.indices.tolist(),
                values=sv.values.tolist(),
            ),
        },
        payload={                              # Slide-13 shape
            "document_id":   doc_id,
            "chunk_index":   idx,
            "tenant_id":     TENANT_ID,
            "source_url":    source,
            "text":          text,
        },
    ))

# Upsert in batches of 50 so we never POST a massive payload at once
BATCH = 50
for start in track(range(0, len(points), BATCH), description="Upserting"):
    qdrant.upsert(
        collection_name=COLLECTION,
        points=points[start:start + BATCH],
        wait=True,         # ingest jobs want durable writes (Slide 14)
    )

# ---- Recap -------------------------------------------------------------
info = qdrant.get_collection(COLLECTION)
print(f"\n[bold green]Done.[/bold green] Collection now holds [bold]{info.points_count}[/bold] points.")
print(f"Dashboard: [link]http://localhost:6333/dashboard#/collections/{COLLECTION}[/link]")
print("\nNext: any of the 04_search/* examples.")
