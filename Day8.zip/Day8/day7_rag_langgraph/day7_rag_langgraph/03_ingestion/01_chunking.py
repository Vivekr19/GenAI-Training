"""
Slide 12 — Chunking is the single biggest quality lever
========================================================
We split a real markdown doc with the RecursiveCharacterTextSplitter and
show what the knobs actually do:
    * chunk_size — how much text per chunk
    * chunk_overlap — sliding window so a sentence isn't orphaned at a boundary
    * separators — natural boundaries first (\\n\\n, \\n, sentence, word)

Run:
    uv run python 03_ingestion/01_chunking.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich import print
from rich.table import Table
from langchain_text_splitters import RecursiveCharacterTextSplitter

DOC = Path(__file__).resolve().parent.parent / "data" / "sample_docs" / "acme_handbook.md"
text = DOC.read_text(encoding="utf-8")
print(f"[bold]Source:[/bold] {DOC.name} ({len(text)} characters)\n")


def chunk(size: int, overlap: int) -> list[str]:
    """A tokenizer-aware splitter is ideal in production (Slide 12). Here we
    measure in characters for simplicity — same idea, easier to inspect."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=size,
        chunk_overlap=overlap,
        # 'Natural boundaries' from the slide — try these in order
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    return splitter.split_text(text)


# Try a few combinations so the knobs become visible
configs = [
    (200, 0,   "tiny + no overlap"),
    (200, 40,  "tiny + 20% overlap"),
    (600, 80,  "[bold green]recommended[/bold green] (~Slide 12)"),
    (4000, 0,  "one mega-chunk"),
]

table = Table(title="Chunking knobs — same document, different settings")
table.add_column("size")
table.add_column("overlap")
table.add_column("# chunks")
table.add_column("avg chars/chunk")
table.add_column("note")
for size, overlap, note in configs:
    chunks = chunk(size, overlap)
    avg = sum(len(c) for c in chunks) / len(chunks)
    table.add_row(str(size), str(overlap), str(len(chunks)), f"{avg:.0f}", note)

print(table)

# --- Overlap demonstration with a simple string ---
print("\n[bold]Explicit overlap demo[/bold] (no natural boundaries)\n")
demo_text = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
demo_splitter = RecursiveCharacterTextSplitter(
    chunk_size=20,
    chunk_overlap=5,
    separators=[""]  # Only split by character count
)
demo_chunks = demo_splitter.split_text(demo_text)
print(f"Demo text: {demo_text}")
print(f"Chunks: {demo_chunks}")
if len(demo_chunks) >= 2:
    print(f"\n[cyan]End of chunk 0:[/cyan] ...{demo_chunks[0][-5:]!r}")
    print(f"[cyan]Start of chunk 1:[/cyan] {demo_chunks[1][:5]!r}...")
    print("[dim]These 5 characters are the overlap between chunks.[/dim]")

# Show overlap visually
# print("\n[bold]Why overlap matters[/bold] (zoom in on the boundary)")
# small = chunk(600, 80)
# if len(small) >= 2:
#     print(small)
#     print(f"\n[cyan]End of chunk 0:[/cyan] ...{small[0][-80:]!r}")
#     print(f"[cyan]Start of chunk 1:[/cyan] {small[1][:80]!r}...")
#     print("[dim]Overlap is the shared tail/head — it stops a sentence from being orphaned.[/dim]")

print("""
[dim]Takeaway:[/dim] 500–800 tokens, 10–15% overlap, natural boundaries.
The pipeline in 03_ingestion/02_pipeline.py uses these defaults.
""")
